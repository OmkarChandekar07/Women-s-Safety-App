import 'package:flutter/material.dart';

class SelfAwarenessScreen extends StatelessWidget {
  final List<String> tips = [
    '1.Stay in well-lit areas at night.',
    '2.Always let someone know your    whereabouts.',
    '3.Be aware of your surroundings.',
    '4.Carry a safety device, like pepper spray.'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     backgroundColor: const Color.fromARGB(255, 63, 17, 177),

      appBar: AppBar( 
        backgroundColor: Color.fromARGB(255, 63, 17, 177),
        title: Text('Self Awareness Tips',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),),),
      body: ListView.builder(
        itemCount: tips.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(tips[index],style: TextStyle(color: Colors.white,fontSize: 20),),
          );
        },
      ),
    );
  }
}
