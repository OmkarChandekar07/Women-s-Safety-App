import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/MainMenu/LiveSafe/LiveSafe.dart';
import 'package:flutter_application_1/MainMenu/emergeincies.dart/emergency.dart';
import 'package:flutter_application_1/MainMenu/buttons/self_awareness_screen.dart';
import 'package:flutter_application_1/MainMenu/slider.dart';

class MainmenuScreen extends StatelessWidget {
  const MainmenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color.fromARGB(255, 63, 17, 177),
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 63, 17, 177),
          title: Text( "Nari App",style: TextStyle(color: Colors.white),),

          actions: [
            IconButton(
                onPressed: FirebaseAuth.instance.signOut,
                icon: Icon(
                  size: 30,
                  Icons.logout,
                  color: Colors.white,
                ))
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SliderCard(),
              
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Text("Emergency",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white),),
                        Container(height: 40,width:40,
                          child: Image.asset("asset/Imges/alert.png")),
                      ],
                    ),
                  ),

                  Emergency(),

                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Text("LiveSafe",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.white),),
                        Container(height: 40,width:40,
                          child: Image.asset("asset/Imges/hospital.png")),
                      ],
                    ),
                  ),
                  Livesafe(),
                  SizedBox(height: 20,),
              
              
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                          onPressed: () {
                            Navigator.push(  context,MaterialPageRoute(
                                  builder: (context) =>  SelfAwarenessScreen(),
                                  ),);
                          },
                          child: const Text(
                            "SelfAwerness",
                            style: TextStyle(fontSize: 20),
                          )),
              
                      const SizedBox( width: 10,),
              
                      ElevatedButton(
                          onPressed: () {
                          },
                          child:const Text(
                            "Panic Button",
                            style: TextStyle(fontSize: 20),
                          ),),
                    ],
                  ),
                  SizedBox(height: 15,),
              
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                          onPressed: () {},
                          child: const Text(
                            "    Contacts    ",
                            style: TextStyle(fontSize: 20),
                          )),
                      SizedBox(width: 15,),
              
                      ElevatedButton(
                          onPressed: () {},
                          child: const Text(
                            " Safety Laws",
                            style: TextStyle(fontSize: 20),
                          )),
                    ],
                  ),
                 const SizedBox(height: 15,),
                  const Text("Below Update Commiung Soon...",style: TextStyle(color: Colors.blueGrey),),
              
                  OutlinedButton(
                      onPressed: () {},
                      child:const Text(
                        "Record Vedio & Audio",
                        style: TextStyle(fontSize: 20),
                      )),
              
                 
                ],
              ),
            ),
          ),
        ));
  }
}
