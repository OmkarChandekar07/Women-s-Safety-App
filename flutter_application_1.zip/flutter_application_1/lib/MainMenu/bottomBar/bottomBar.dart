import 'package:flutter/material.dart';
import 'package:flutter_application_1/MainMenu/bottomBar/contacts.dart';
import 'package:flutter_application_1/MainMenu/bottomBar/home.dart';
import 'package:flutter_application_1/MainMenu/bottomBar/profile.dart';

class Bottompage extends StatefulWidget {
  const Bottompage({super.key});

  @override
  State<Bottompage> createState() => _BottompageState();
}

class _BottompageState extends State<Bottompage> {
  List<Widget>pages=[ 
    HomePage(),
    ContacPage(),
    ProfilePage(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:pages[0], 
      bottomNavigationBar: BottomNavigationBar(
        items:[
          BottomNavigationBarItem(
            label: 'Home',
            icon: Icon(Icons.home),
            ),
            BottomNavigationBarItem(
            label: 'Contacts',
            icon: Icon(Icons.home),
            ),
            BottomNavigationBarItem(
            label: 'Profile',
            icon: Icon(Icons.home),
            ),
        ] 
        ),
    );
  }
}