import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/Authentication/AuthScreen.dart';
import 'package:flutter_application_1/MainMenu/MainMenu.dart';
import 'package:flutter_application_1/Authentication/SplashScreen.dart';
//import 'package:flutter_application_1/firebase_options.dart';
import 'Authentication/firebase_options.dart';


void main()async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Women Safety App',
      theme: ThemeData(
        primarySwatch: Colors.pink,
      ),
     home: StreamBuilder(
     stream: FirebaseAuth.instance.authStateChanges(),
     builder: (context,snapshot){
        if (snapshot.connectionState == ConnectionState.waiting) {
         return Splashscreen(); 
        }
          if(snapshot.hasData){
            return MainmenuScreen();
          }
          return Authscreen();
     },),
    );
  }
}
